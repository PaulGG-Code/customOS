#!/bin/bash
# init
function pause(){
echo ''
echo 'Press any key to continue with next step ...';   read -p "$*"
clear
}
clear
#
# Processing Build
#
echo 'Setp 1: Installing Kali Bootstrap'
cd /home/kali/Downloads/
apt install curl git live-build cdebootstrap
echo 'Setp 2: Creating Kali Live build Directory Structure'
git clone https://gitlab.com/kalilinux/build-scripts/live-build-config.git
echo 'Step 3: Downloading Preceed file'
cd /home/kali/Downloads/live-build-config
wget https://gitlab.com/kalilinux/recipes/kali-preseed-examples/-/raw/master/kali-linux-full-unattended.preseed -O kali-config/common/debian-installer/preseed.cfg
echo 'Step 4: Creating Directory Structure'
cd /home/kali/Downloads/kali-custom
cp -r root /home/kali/Downloads/live-build-config/kali-config/common/includes.chroot/
cp -r etc /home/kali/Downloads/live-build-config/kali-config/common/includes.chroot/

cat <<EOF > kali-config/common/includes.binary/isolinux/install.cfg
label install
    menu label ^Install Automated
    linux /install/vmlinuz
    initrd /install/initrd.gz
    append vga=788 -- quiet file=/cdrom/install/preseed.cfg locale=en_US keymap=us hostname=kali domain=local.lan
EOF

cp kali.list.chroot /home/kali/Downloads/live-build-config/kali-config/variant-gnome/package-lists/
echo 'Creating and moving deb files to the isntall location'
mkdir /home/kali/Downloads/live-build-config/kali-config/common/packages.chroot
cp packages/*.deb /home/kali/Downloads/live-build-config/kali-config/common/packages.chroot
clear
echo 'Copying tools to /usr/bin'
cp -r tools/ /home/kali/Downloads/live-build-config/kali-config/common/includes.chroot/usr/bin/.
echo '================================================================='
echo '================================================================='
echo 'Step 5: Build the ISO....'
echo '=================================================================='
echo 'If you wish to redirect this install to a local repository'
echo 'you may edit the live-build-config/auto/config file at this time'
echo 'If you want to use the default repository the press Enter'
pause
cd /home/kali/Downloads/live-build-config
./build.sh --distribution kali-rolling --variant gnome --verbose
