#!/bin/bash
#===========================
# Start init
#===========================
function pause(){
    echo 'Press any key to continue...';   read -p "$*"
}
#  End INIT

#=================================================
#===========  Start Main script ==================
#=========== Version 2.0.0  8-30-2018 ============
#=================================================
clear
#========================================
#========== Get Desktop Environment======
#========================================
# menu items
echo ''
    echo "          Select Desktop Environment"
    echo " ____________________________________________________________________"
    echo "1) Install Default Kali"
    echo "2) Install Core Kali"
    echo "3) Install Kali with top10"
    echo " "
    echo "____________________________________________________________________"
    echo " "
echo '         Eneter item to complete';read option
case "$option" in
   1)  
cat << EOF > kali.list.chroot
# Live image
# You always want these:
kali-linux-core
kali-desktop-live
# Metapackages
# You can customize the set of Kali metapackages (groups of tools) to install
# For the complete list see: https://tools.kali.org/kali-metapackages
#kali-linux-core
#kali-tools-top10
kali-linux-default
#kali-linux-large
#kali-linux-everything
EOF
;;
   2) 
cat << EOF > kali.list.chroot
# Live image
# You always want these:
kali-linux-core
kali-desktop-live
# Metapackages
# You can customize the set of Kali metapackages (groups of tools) to install
# For the complete list see: https://tools.kali.org/kali-metapackages
kali-linux-core
#kali-tools-top10
#kali-linux-default
#kali-linux-large
#kali-linux-everything
EOF
;;
    3)
cat << EOF > kali.list.chroot
# Live image
# You always want these:
kali-linux-core
kali-desktop-live
# Metapackages
# You can customize the set of Kali metapackages (groups of tools) to install
# For the complete list see: https://tools.kali.org/kali-metapackages
#kali-linux-core
kali-tools-top10
#kali-linux-default
#kali-linux-large
#kali-linux-everything
EOF
;;
  esac
cat software >> kali.list.chroot
bash processing.sh
